package com.example.android.datepicker;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.sqlite.SQLiteOpenHelper;
import android.icu.text.SimpleDateFormat;
import android.icu.util.Calendar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    EditText editText;
    Calendar myCalendar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Calendar c = Calendar.getInstance();
        int weekDay=c.get(Calendar.DAY_OF_WEEK);
        String s;
        if(weekDay==1)
            s="Sunday";
        else if(weekDay==2)
            s="Monday";
        else if(weekDay==3)
            s="Tuesday";
        else if(weekDay==4)
            s="Wednesday";



        else if(weekDay==5)
            s="Thursday";

        else if(weekDay==6)
            s="Friday";
        else
            s="Saturday";


        setdate(s);
        try {
            myCalendar = Calendar.getInstance();
           // private int dayOfMonth,monthOfYear,year;



            editText= (EditText) findViewById(R.id.Birthday);

            updateLabel();


            final DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {

                @Override
                public void onDateSet(DatePicker view, int year, int monthOfYear,
                                      int dayOfMonth) {
                    // TODO Auto-generated method stub
                    myCalendar.set(Calendar.YEAR, year);
                    myCalendar.set(Calendar.MONTH, monthOfYear);
                    myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                    SimpleDateFormat simpledateformat = new SimpleDateFormat("EEEE");
                    Date date = new Date(year,monthOfYear, dayOfMonth-1);
                    String dayOfWeek = simpledateformat.format(date);
                    String weekDay = dayOfWeek;
                    setdate(weekDay);

                    editText= (EditText) findViewById(R.id.Birthday);
                    updateLabel();

                }

            };


            editText.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {

                    new DatePickerDialog(MainActivity.this, date, myCalendar
                            .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                            myCalendar.get(Calendar.DAY_OF_MONTH)).show();

                }
            });

        } catch (Exception e) {
            Toast tb = Toast.makeText(this, "issue in oncreate function ", Toast.LENGTH_SHORT);
            tb.show();
        }

    }



    private void setdate(String weekDay)
    {
        String[] mon = new String[] {"DS", "CO","DC"};
        String[] Tue = new String[] {"DS", "NW","DMS"};
        String[] wed = new String[] {"DMS", "NW","CO"};
        String[] thu = new String[] {"DS", "SW","DMS"};
        String[] fri = new String[] {"CO", "NW","DMS"};


        if(weekDay.equals("Monday"))
        {
            editText= (EditText) findViewById(R.id.subject1);
            weekDay=mon[0];
            editText.setText(weekDay);
            editText= (EditText) findViewById(R.id.subject2);
            weekDay=mon[1];
            editText.setText(weekDay);
            editText= (EditText) findViewById(R.id.subject3);
            weekDay=mon[2];
            editText.setText(weekDay);
        }
        else if(weekDay.equals("Tuesday"))
        {
            editText= (EditText) findViewById(R.id.subject1);
            weekDay=Tue[0];
            editText.setText(weekDay);
            editText= (EditText) findViewById(R.id.subject2);
            weekDay=Tue[1];
            editText.setText(weekDay);
            editText= (EditText) findViewById(R.id.subject3);
            weekDay=Tue[2];
            editText.setText(weekDay);
        }
        else if(weekDay.equals("Wednesday"))
        {
            editText= (EditText) findViewById(R.id.subject1);
            weekDay=wed[0];
            editText.setText(weekDay);
            editText= (EditText) findViewById(R.id.subject2);
            weekDay=wed[1];
            editText.setText(weekDay);
            editText= (EditText) findViewById(R.id.subject3);
            weekDay=wed[2];
            editText.setText(weekDay);
        }
        else if(weekDay.equals("Thursday"))
        {

            editText= (EditText) findViewById(R.id.subject1);
            weekDay=thu[0];
            editText.setText(weekDay);
            editText= (EditText) findViewById(R.id.subject2);
            weekDay=thu[1];
            editText.setText(weekDay);
            editText= (EditText) findViewById(R.id.subject3);
            weekDay=thu[2];
            editText.setText(weekDay);
        }
        else if(weekDay.equals("Friday"))
        {
            editText= (EditText) findViewById(R.id.subject1);
            weekDay=fri[0];
            editText.setText(weekDay);
            editText= (EditText) findViewById(R.id.subject2);
            weekDay=fri[1];
            editText.setText(weekDay);
            editText= (EditText) findViewById(R.id.subject3);
            weekDay=fri[2];
            editText.setText(weekDay);
        }
        else if(weekDay.equals("Sunday")) {
            editText= (EditText) findViewById(R.id.subject1);
            weekDay = "holiday1";
            editText.setText(weekDay);
            editText= (EditText) findViewById(R.id.subject2);
            weekDay = "holiday2";
            editText.setText(weekDay);
            editText= (EditText) findViewById(R.id.subject3);
            weekDay = "holiday3";
            editText.setText(weekDay);

        }
        else {
            editText= (EditText) findViewById(R.id.subject1);
            weekDay = "holiday";
            editText.setText(weekDay);
            editText= (EditText) findViewById(R.id.subject2);
            weekDay = "holiday";
            editText.setText(weekDay);
            editText= (EditText) findViewById(R.id.subject3);
            weekDay = "holiday";
            editText.setText(weekDay);

        }
    }
    private void updateLabel() {
        try {
            String myFormat = "dd/MM/yy"; //In which you need put here
            SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

            editText.setText(sdf.format(myCalendar.getTime()));

        } catch (Exception e) {
            Toast tb = Toast.makeText(this, "issue is in update label function and the issue is\n\n"+e, Toast.LENGTH_LONG);
            tb.show();
        }
    }
}
