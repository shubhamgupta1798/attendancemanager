package com.example.android.trial_edittext;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;
import java.util.List;

public class Main4Activity extends AppCompatActivity {

    StarbuzzDatabaseHelper db1=new StarbuzzDatabaseHelper(this);
    long a[]={0,0};
    String attended[]={"attended","not attended"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
        checkatt();
    }
    public void checkatt()
    {
        long c=0;

        LinearLayout l1=(LinearLayout)findViewById(R.id.ll1);
        SQLiteDatabase db = db1.getReadableDatabase();
        try{c=db1.subjecttotal(db,"dc");


        }

        catch (Exception E)
        {
            Toast.makeText(this,""+E,Toast.LENGTH_LONG).show();
        }
        String c1=""+c;
        //SQLiteDatabase db = db1.getReadableDatabase();
        Cursor res = db1.findallsubjectsin(db);
        if(res.getCount()==0) {
            c = 0;
            c1=c1+" "+c;
        }


        else{
            int finalv=res.getCount();
            int j=0;
        while (res.moveToNext()) {
            j++;

            TextView e1=new TextView(Main4Activity.this);
            e1.setId(j+100);


            LinearLayout.LayoutParams b1 = new LinearLayout.LayoutParams(800, LinearLayout.LayoutParams.WRAP_CONTENT,250);
            e1.setLayoutParams(b1);
            l1.addView(e1);
            b1.setMargins(0, 0, 0, 8);

            e1.setText(res.getString(0));


            c= db1.subjecttotal(db,res.getString(0));
            long c3=db1.subjectattended(db,res.getString(0));
            try{
                PieChart c12=new PieChart(Main4Activity.this);
                a[0]=c3;
                a[1]=c-c3;
                LinearLayout.LayoutParams b12 = new LinearLayout.LayoutParams(800, LinearLayout.LayoutParams.WRAP_CONTENT);
                c12.setLayoutParams(b12);
                l1.addView(c12);
                c12.setId(j+200);
                if((a[0]+a[1])!=0)
                {setuppie(j);
                c12.setRotationAngle(0);
                c12.setRotationEnabled(false);
                c12.getLayoutParams().height = 400;
                c12.getLayoutParams().width = 600;}
               }
            catch (Exception E)
            {
                Toast.makeText(this,""+E,Toast.LENGTH_LONG).show();
            }
            //e1.setText(""+c+" "+c3);
            c1=c1+" "+res.getString(0)+c;
            Toast.makeText(this,""+res.getString(0),Toast.LENGTH_LONG).show();

        }}


        c=db1.check(db);
        c1=c1+" "+c;

        try{c=db1.subjectattended(db,"dc");
        }
        catch (Exception E)
        {
            Toast.makeText(this,""+E,Toast.LENGTH_LONG).show();
        }
        c1=c1+" "+ c;


    }
    private void setuppie(int j){


        List<PieEntry> pieE=new ArrayList<>();
        for(int i=0;i<a.length;i++)
        {
            pieE.add(new PieEntry(a[i],attended[i]));
            //Toast.makeText(Main4Activity.this,""+a[i],Toast.LENGTH_LONG).show();
        }
        PieDataSet dataSet= new PieDataSet(pieE,"");
        dataSet.setColors(ColorTemplate.COLORFUL_COLORS);
        PieData data=new PieData(dataSet);
        PieChart chart = (PieChart)findViewById(j+200);
        chart.setData(data);
        chart.invalidate();

    }
}
