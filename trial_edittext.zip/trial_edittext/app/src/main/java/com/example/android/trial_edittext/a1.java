package com.example.android.trial_edittext;

import android.app.DatePickerDialog;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.icu.text.SimpleDateFormat;
import android.icu.util.Calendar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.util.Date;
import java.util.Locale;

import static android.widget.Toast.LENGTH_LONG;
import static android.widget.Toast.LENGTH_SHORT;
import static android.widget.Toast.makeText;

public class a1 extends AppCompatActivity {

    EditText editText;
    Calendar myCalendar;
    EditText editName,editSurname,editMarks;
    private SQLiteDatabase db;
    private Cursor cursor;
    Button btn,btnviewAll;

    //SQLiteOpenHelper starbuzzDatabaseHelper = new StarbuzzDatabaseHelper(this);
    StarbuzzDatabaseHelper db1=new StarbuzzDatabaseHelper(this);
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_a1);
        Calendar c = Calendar.getInstance();

        editName = (EditText)findViewById(R.id.subject1);
        editSurname = (EditText)findViewById(R.id.subject2);
        editMarks = (EditText)findViewById(R.id.subject3);
        Toast.makeText(a1.this,"hello",Toast.LENGTH_LONG).show();

        btn = (Button)findViewById(R.id.button_add);
        btnviewAll = (Button)findViewById(R.id.button_viewAll);

        int weekDay=c.get(Calendar.DAY_OF_WEEK);
        String s;
        if(weekDay==1)
            s="Sunday";
        else if(weekDay==2)
            s="Monday";
        else if(weekDay==3)
            s="Tuesday";
        else if(weekDay==4)
            s="Wednesday";



        else if(weekDay==5)
            s="Thursday";

        else if(weekDay==6)
            s="Friday";
        else
            s="Saturday";


        setdate(s);



        try {
            myCalendar = Calendar.getInstance();
            // private int dayOfMonth,monthOfYear,year;



            editText= (EditText) findViewById(R.id.Birthday);

            updateLabel();


            final DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {

                @Override
                public void onDateSet(DatePicker view, int year, int monthOfYear,
                                      int dayOfMonth) {
                    // TODO Auto-generated method stub
                    myCalendar.set(Calendar.YEAR, year);
                    myCalendar.set(Calendar.MONTH, monthOfYear);
                    myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                    SimpleDateFormat simpledateformat = new SimpleDateFormat("EEEE");
                    Date date = new Date(year,monthOfYear, dayOfMonth-1);
                    String dayOfWeek = simpledateformat.format(date);
                    String weekDay = dayOfWeek;
                    setdate(weekDay);

                    editText= (EditText) findViewById(R.id.Birthday);
                    updateLabel();

                }

            };


            editText.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {

                    new DatePickerDialog(a1.this, date, myCalendar
                            .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                            myCalendar.get(Calendar.DAY_OF_MONTH)).show();

                }
            });

        } catch (Exception e) {
            Toast tb = makeText(this, "issue in oncreate function ", LENGTH_SHORT);
            tb.show();
        }
        //AddData();

    }
    public void viewAll(View view) {
        // btnviewAll.setOnClickListener(
        //       new View.OnClickListener() {
        //         @Override
        //       public void onClick(View v) {
        try{ Cursor res = db1.getAllData11();
            if(res.getCount() == 0) {
                // show message
                showMessage("Error","Nothing found");
                return;
            }

            StringBuffer buffer = new StringBuffer();
            while (res.moveToNext()) {
                buffer.append("Id :"+ res.getString(0)+"\n");
                buffer.append("date :"+ res.getString(1)+"\n");
                buffer.append("subject :"+ res.getString(2)+"\n");
                buffer.append("what happened :"+ res.getString(3)+"\n");
            }

            // Show all data
            showMessage("Data",buffer.toString());
        }
        catch(Exception e)
        {
            Toast.makeText(this,"error in view"+e,LENGTH_LONG).show();
        }
    }
    // );
    //}
    public void showMessage(String title,String Message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();
    }
    public  void AddData(View view) {
        //btn.setOnClickListener(
        //      new View.OnClickListener() {
        //        @Override
        //      public void onClick(View v) {
        try {
            RadioGroup radioGroup = (RadioGroup) findViewById(R.id.RGroup6);
            int  radioButtonID = radioGroup.getCheckedRadioButtonId();
            editText= (EditText) findViewById(R.id.Birthday);
            String s=editText.getText().toString();
            RadioButton radioButton = (RadioButton) radioGroup.findViewById(radioButtonID);
            String c = (String) radioButton.getText();
            String c1;
            if(c.equals("holiday"))
            {c1="-1";

                boolean isInserted = db1.insertData11(s,c,c1);}
            else if(c.equals("bunk"))
            {
                c1="-2";
                boolean isInserted = db1.insertData11(s,c,c1);
            }
            else{
                radioButton = (RadioButton) radioGroup.findViewById(radioButtonID);
                c = (String) radioButton.getText();
                radioGroup = (RadioGroup) findViewById(R.id.RGroup1);
                radioButtonID = radioGroup.getCheckedRadioButtonId();
                editText= (EditText) findViewById(R.id.Birthday);
                s=editText.getText().toString();
                radioButton = (RadioButton) radioGroup.findViewById(radioButtonID);
                c = (String) radioButton.getText();

                if(c.equals("no"))
                    c1="2";
                else if(c.equals("yes"))
                    c1="3";
                else
                    c1="4";
                editText= (EditText) findViewById(R.id.subject1);
                String sub=editText.getText().toString();
                boolean isInserted = db1.insertData11(s,sub,c1);
                if (isInserted == true)
                    Toast.makeText(a1.this, "Data Inserted", Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(a1.this, "Data not Inserted", Toast.LENGTH_LONG).show();
            }} catch (Exception e) {
            Toast.makeText(this, "there is an exception" + e, Toast.LENGTH_LONG).show();
        }
    }
            /*    }
        );
    }*/


    private void setdate(String weekDay)
    {
        String[] mon = new String[] {"DS", "CO","DC"};
        String[] Tue = new String[] {"DS", "NW","DMS"};
        String[] wed = new String[] {"DMS", "NW","CO"};
        String[] thu = new String[] {"DS", "SW","DMS"};
        String[] fri = new String[] {"CO", "NW","DMS"};


       // if(weekDay.equals("Monday"))
        //{

           /* weekDay="MONDAY";
            String itemname="";

            editText= (EditText) findViewById(R.id.subject1);

                //Cursor c = db1.findsubject("1", weekDay);

            try{
           // StringBuffer buffer = new StringBuffer();
                //c.moveToFirst();
            /*do {
                buffer.append( c.getString(2));
               //buffer.append("number of subjects :"+ res.getString(3)+"\n");
            } while (c.moveToNext());
                itemname= buffer.toString();
            if(c!=null)
                itemname= c.getString(2);
                c.close();
            }catch (Exception e)
            {
                Toast.makeText(a1.this,"error"+e,LENGTH_LONG).show();
            }


            weekDay=itemname;
            editText.setText(weekDay);

            editText= (EditText) findViewById(R.id.subject2);
            itemname="";
            c=null;
            try {
                c = db1.findsubject("2", weekDay);
            }
            catch (Exception e)
            {
                Toast.makeText(a1.this,"error"+e,LENGTH_LONG).show();
            }
            try{
                StringBuffer buffer = new StringBuffer();
                //c.moveToFirst();

                   // buffer.append( c.getString(2));
                    //buffer.append("number of subjects :"+ res.getString(3)+"\n");

                itemname= c.getString(2);
                c.close();
            }catch (Exception e)
            {
                Toast.makeText(a1.this,"error"+e,LENGTH_LONG).show();
            }


            weekDay=itemname;
            editText.setText(weekDay);
            editText= (EditText) findViewById(R.id.subject3);
            itemname="";
            c=null;
            try {
                c = db1.findsubject("3", weekDay);
            }
            catch (Exception e)
            {
                Toast.makeText(a1.this,"error"+e,LENGTH_LONG).show();
            }
            try{
                StringBuffer buffer = new StringBuffer();
                //c.moveToFirst();
                /*do {
                    buffer.append( c.getString(2));
                    //buffer.append("number of subjects :"+ res.getString(3)+"\n");
                } while (c.moveToNext());
                itemname= buffer.toString();*/
                /*itemname= c.getString(2);
                c.close();
            }catch (Exception e)
            {
                Toast.makeText(a1.this,"error"+e,LENGTH_LONG).show();
            }


            weekDay=itemname;

            editText.setText(weekDay);
        }*/
         if(weekDay.equals("Tuesday"))
        {
            editText= (EditText) findViewById(R.id.subject1);
            weekDay=Tue[0];
            editText.setText(weekDay);
            editText= (EditText) findViewById(R.id.subject2);
            weekDay=Tue[1];
            editText.setText(weekDay);
            editText= (EditText) findViewById(R.id.subject3);
            weekDay=Tue[2];
            editText.setText(weekDay);
        }
        else if(weekDay.equals("Wednesday"))
        {
            editText= (EditText) findViewById(R.id.subject1);
            weekDay=wed[0];
            editText.setText(weekDay);
            editText= (EditText) findViewById(R.id.subject2);
            weekDay=wed[1];
            editText.setText(weekDay);
            editText= (EditText) findViewById(R.id.subject3);
            weekDay=wed[2];
            editText.setText(weekDay);
        }
        else if(weekDay.equals("Thursday"))
        {

            editText= (EditText) findViewById(R.id.subject1);
            weekDay=thu[0];
            editText.setText(weekDay);
            editText= (EditText) findViewById(R.id.subject2);
            weekDay=thu[1];
            editText.setText(weekDay);
            editText= (EditText) findViewById(R.id.subject3);
            weekDay=thu[2];
            editText.setText(weekDay);
        }
        else if(weekDay.equals("Friday"))
        {
            editText= (EditText) findViewById(R.id.subject1);
            weekDay=fri[0];
            editText.setText(weekDay);
            editText= (EditText) findViewById(R.id.subject2);
            weekDay=fri[1];
            editText.setText(weekDay);
            editText= (EditText) findViewById(R.id.subject3);
            weekDay=fri[2];
            editText.setText(weekDay);
        }
        else if(weekDay.equals("Sunday")) {
            editText= (EditText) findViewById(R.id.subject1);
            weekDay = "holiday1";
            editText.setText(weekDay);
            editText= (EditText) findViewById(R.id.subject2);
            weekDay = "holiday2";
            editText.setText(weekDay);
            editText= (EditText) findViewById(R.id.subject3);
            weekDay = "holiday3";
            editText.setText(weekDay);

        }
        else {
            editText= (EditText) findViewById(R.id.subject1);
            weekDay = "holiday";
            editText.setText(weekDay);
            editText= (EditText) findViewById(R.id.subject2);
            weekDay = "holiday";
            editText.setText(weekDay);
            editText= (EditText) findViewById(R.id.subject3);
            weekDay = "holiday";
            editText.setText(weekDay);

        }
    }
    private void updateLabel() {
        try {
            //Toast.makeText(a1.this,"hello1",Toast.LENGTH_LONG).show();

            String myFormat = "dd/MM/yy"; //In which you need put here
            SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

            editText.setText(sdf.format(myCalendar.getTime()));

        } catch (Exception e) {
            Toast tb = makeText(this, "issue is in update label function and the issue is\n\n"+e, LENGTH_LONG);
            tb.show();
        }
    }
}
