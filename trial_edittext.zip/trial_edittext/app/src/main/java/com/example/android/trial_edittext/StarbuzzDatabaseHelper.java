package com.example.android.trial_edittext;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

/**
 * Created by shubhamgupta on 14/01/18.
 */

class StarbuzzDatabaseHelper extends SQLiteOpenHelper {
        public static final String DATABASE_NAME = "Student.db";
        public static final String TABLE_NAME = "subject1_table";
    public static final String TABLE_NAME2 = "subject2_table";
    public static final String TABLE_NAME1 = "start_table";
        public static final String COL_1 = "ID";
        public static final String COL_2 = "DAY";
        public static final String COL_3 = "SUBJECT";
    public static final String COL1 = "STARTD";
    public static final String COL2 = "ENDD";
    public static final String COL3 = "DAY1";
    public static final String COL4 = "NUMBEROF";
    public static final String TABLE_NAME3 = "student3_table";

    public static final String COL_11 = "ID";
    public static final String COL_12 = "DATE";
    public static final String COL_13 = "SUBJECT";
    public static final String COL_14 = "ATTENDANCE";






    public StarbuzzDatabaseHelper(Context context) {
            super(context, DATABASE_NAME, null, 1);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("create table " + TABLE_NAME +" (ID TEXT,DAY TEXT,SUBJECT TEXT)");
            db.execSQL("create table " + TABLE_NAME1 +" (DAY1 TEXT,NUMBEROF TEXT)");
            db.execSQL("create table " + TABLE_NAME2 +" (STARTD TEXT,ENDD TEXT)");
            db.execSQL("create table " + TABLE_NAME3 +" (ID INTEGER PRIMARY KEY AUTOINCREMENT,DATE TEXT,SUBJECT TEXT,ATTENDANCE TEXT)");

        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
            db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME1);
            db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME2);
            db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME3);

            onCreate(db);
        }
    public boolean insertData(String id,String day,String subject) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_1,id);
        contentValues.put(COL_2,day);
        contentValues.put(COL_3,subject);


        // String Query = "Select * from " + TABLE_NAME + " where " + date + " =? " ;
        //Cursor cursor = db.query(SELECT * FROM TABLE_NAME WHERE DATE == date AND SUBJECT ==subject);

        // Toast.makeText(MainActivity.this,"EXIST",Toast.LENGTH_LONG).show();

        Cursor cursor = db.query(TABLE_NAME,new String[]{"ID","DAY" },"ID=? AND DAY=?",new String[]{id,day},null,null,null  );
        if(cursor.getCount() > 0){
            cursor.close();

            return updateData(id,day,subject);
        }
        long result = db.insert(TABLE_NAME,null ,contentValues);
        if(result == -1)
            return false;
        else
            return true;
    }
    public boolean insertsub(String day,String numberofsubject) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        //contentValues.put(COL1,startd);
        //contentValues.put(COL2,endd);
        contentValues.put(COL3,day);
        contentValues.put(COL4,numberofsubject);
        Cursor cursor = db.query(TABLE_NAME1,new String[]{"DAY1","NUMBEROF"}," DAY1=?",new String[]{day},null,null,null  );
        if(cursor.getCount() > 0){
            cursor.close();

            return updateData1(day,numberofsubject);
        }
        long result = db.insert(TABLE_NAME1,null ,contentValues);
        if(result == -1)
            return false;
        else
            return true;

    }
    public boolean insertstart(String startd,String endd) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL1,startd);
        contentValues.put(COL2,endd);
        //long result=db.update(TABLE_NAME2,contentValues,null,null);

        long result = db.insert(TABLE_NAME2,null ,contentValues);
        if(result == -1)
            return false;
        else
            return true;
    }
    private boolean updateData(String id, String day, String subject) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(COL_1,id);
        contentValues.put(COL_2,day);
        contentValues.put(COL_3,subject);

        long re=db.update(TABLE_NAME,
                contentValues,
                "DAY" + " = ? AND " + "ID"  + " = ?",
                new String[]{day,id});
        if(re == -1)
            return false;
        else
            return true;
    }
    private boolean updateData1(String day, String numberofsubject) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(COL3,day);
        contentValues.put(COL4,numberofsubject);

        long re=db.update(TABLE_NAME1,
                contentValues,
                "DAY1" + " = ?",
                new String[]{day});
        if(re == -1)
            return false;
        else
            return true;
    }
    public Cursor getAllData() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from "+TABLE_NAME,null);
        return res;
    }
    public Cursor getAllData1() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from "+TABLE_NAME2,null);
        return res;
    }
    public Cursor getAllData2() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from "+TABLE_NAME1,null);
        return res;
    }
    public boolean insertData11(String date,String subject,String att) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_12,date);
        contentValues.put(COL_13,subject);
        contentValues.put(COL_14,att);

        // String Query = "Select * from " + TABLE_NAME + " where " + date + " =? " ;
        //Cursor cursor = db.query(SELECT * FROM TABLE_NAME WHERE DATE == date AND SUBJECT ==subject);
        Cursor cursor = db.query(TABLE_NAME3,new String[]{"DATE","SUBJECT" },"DATE=? AND SUBJECT=?",new String[]{date,subject},null,null,null  );
        if(cursor.getCount() > 0){
            cursor.close();

            return updateData11(date,subject,att);
        }
        // Toast.makeText(MainActivity.this,"EXIST",Toast.LENGTH_LONG).show();
        cursor.close();


        long result = db.insert(TABLE_NAME3,null ,contentValues);
        if(result == -1)
            return false;
        else
            return true;
    }
    public Cursor getAllData11() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from "+TABLE_NAME3,null);
        return res;
    }

    public boolean updateData11(String date,String subject,String att) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(COL_12,date);
        contentValues.put(COL_13,subject);
        contentValues.put(COL_14,att);

        db.update(TABLE_NAME3,
                contentValues,
                "DATE" + " = ? AND " + "SUBJECT"  + " = ?",
                new String[]{date,subject});

        return true;

    }

    public Integer deleteData11 (String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_NAME3, "ID = ?",new String[] {id});
    }
    public String findsubject(SQLiteDatabase db,String id,String day)
    {

        Cursor cursor = db.query(TABLE_NAME,new String[]{"ID","DAY","SUBJECT"}," ID=? AND DAY=? ",new String[]{id,day},null,null,null  );
       // Log.w("day",cursor.getString(2));
        //Toast.makeText(context,cursor.getString(2),Toast.LENGTH_LONG).show();
        if(cursor.getCount() <= 0){
            cursor.close();
            db.close();
            return "hello";
        }
        else{
            if(cursor.moveToFirst())
            {
        String value=cursor.getString(cursor.getColumnIndex("SUBJECT"));
                db.close();
        return value;


    }
        else
        {
            return "error1";
        }}
    }

    public int find11(SQLiteDatabase db,String s)
    {
       // SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_NAME1,new String[]{"DAY1","NUMBEROF"}," DAY1=?",new String[]{s},null,null,null  );
        if(cursor.getCount() <= 0){
            cursor.close();
            db.close();
        return -1;
        }


        else
        {
            if(cursor.moveToFirst())
            {String value=cursor.getString(cursor.getColumnIndex("NUMBEROF"));
            int finalValue=Integer.parseInt(value);
                db.close();
            return finalValue;
        }
        else
            {
                db.close();

            return -1;
        }



    }
}
    public boolean checkday(SQLiteDatabase db,String day)
    {
        Cursor cursor = db.query(TABLE_NAME1,new String[]{"DAY1","NUMBEROF"}," DAY1=?",new String[]{day},null,null,null  );
        if(cursor.getCount() <= 0){
            cursor.close();
            db.close();
            return false;}
        else
            return true;
    }
}





