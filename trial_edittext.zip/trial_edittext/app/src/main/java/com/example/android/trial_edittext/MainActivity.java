package com.example.android.trial_edittext;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.icu.text.SimpleDateFormat;
import android.icu.util.Calendar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Date;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static android.widget.Toast.LENGTH_LONG;

public class MainActivity extends AppCompatActivity {



    private LinearLayout lnrDynamicEditTextHolder;
    private EditText edtNoCreate,ed,e1;

    private SQLiteDatabase db;
    private Cursor cursor;
    Button btnCreate ;
    Integer count=0;

    //SQLiteOpenHelper starbuzzDatabaseHelper = new StarbuzzDatabaseHelper(this);
    StarbuzzDatabaseHelper db1=new StarbuzzDatabaseHelper(this);
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        SQLiteDatabase db = db1.getReadableDatabase();
        boolean r=db1.checkdatafilled(db);
        if(r)
        Toast.makeText(this,"data already added please press  next2",LENGTH_LONG).show();


        lnrDynamicEditTextHolder = (LinearLayout) findViewById(R.id.lnrDynamicEditTextHolder);
        edtNoCreate = (EditText) findViewById(R.id.edtNoCreate);
        btnCreate = (Button) findViewById(R.id.edit);

        Spinner color = (Spinner) findViewById(R.id.day);//color.getSelectedItem()
         String s = String.valueOf(color.getSelectedItem());

        btnCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(edtNoCreate.getText().toString().length()>0) {
                    SQLiteDatabase db = db1.getWritableDatabase();
                    Spinner color = (Spinner) findViewById(R.id.day);//color.getSelectedItem()
                    String s = String.valueOf(color.getSelectedItem());
                    if((db1.checkday(db,s)==false)){
                    try {
                        lnrDynamicEditTextHolder.removeAllViews();
                    } catch (Throwable e) {
                        e.printStackTrace();
                    }

                    int length = Integer.parseInt(edtNoCreate.getText().toString());

                    for (int i=1;i<length+1;i++){
                        EditText editText = new EditText(MainActivity.this);
                        editText.setId(i);

                        editText.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                        editText.setHint("SUBJECT NAME "+(i));
                        lnrDynamicEditTextHolder.addView(editText);


                    }}
                }
            }
        });
    }
    public void adddatato(View View)
    {

        try{
            int check1=0,check2=0,check3=0;
            Spinner color = (Spinner) findViewById(R.id.day);//color.getSelectedItem()
            String s = String.valueOf(color.getSelectedItem());
            edtNoCreate = (EditText) findViewById(R.id.edtNoCreate);
            int length = Integer.parseInt(edtNoCreate.getText().toString());
            if(count==0)
            {

                count++;
                e1 = (EditText) findViewById(R.id.startd);
                String startd = e1.getText().toString();
                e1 = (EditText) findViewById(R.id.endd);
                String endd = e1.getText().toString();
                Toast.makeText(this,""+endd,Toast.LENGTH_LONG).show();
                check1=validate(startd);
                check2=validate(endd);
                if(check1==1 && check2==1){
                    SQLiteDatabase db = db1.getWritableDatabase();
                boolean r=db1.insertstart(db,startd,endd);
                if(r) {
                    Toast.makeText(this, "added date", Toast.LENGTH_LONG).show();
                    e1 = (EditText) findViewById(R.id.startd);
                    e1.setEnabled(false);
                    e1 = (EditText) findViewById(R.id.endd);
                    e1.setEnabled(false);
                }else
                    Toast.makeText(this,"not added date",Toast.LENGTH_LONG).show();}
                else
                {
                    if(check1==-1)
                    {
                        e1 = (EditText) findViewById(R.id.startd);
                        e1.setError("Enter valid date");
                        Toast.makeText(this,"error in date1 ",Toast.LENGTH_LONG).show();

                    }
                    else if(check2==-1)
                    {
                        e1 = (EditText) findViewById(R.id.endd);
                        e1.setError("Enter valid date");
                        Toast.makeText(this,"error in date2",Toast.LENGTH_LONG).show();

                    }
                    count--;

                }

            }
            String numberof=edtNoCreate.getText().toString();
            if(check1!=-1&&check2!=-1) {
                SQLiteDatabase db = db1.getWritableDatabase();
                boolean r = db1.insertsub(db,s, numberof);
                if (r) {
                    Toast.makeText(this, "added sub", Toast.LENGTH_LONG).show();
                    check3++;
                }else
                    Toast.makeText(this, "not added sub", Toast.LENGTH_LONG).show();

            }

            if(numberof.equals(""))
                edtNoCreate.setError("ENTER NUMBER OF SUBJECTS");
            else
                check3++;
            if(check1!=-1 && check2!=-1 && check3!=0)
            for (int i=0;i<length;i++){
                ed=(EditText) lnrDynamicEditTextHolder.findViewById(i+1);
                String c="";
                try {
                    c = ed.getText().toString();
                }
                catch(Exception e){
                    Toast.makeText(this,"error in edittext"+e,Toast.LENGTH_LONG).show();

                }
                Integer c2=i+1;
                String cz=""+c2;
                if(s=="SELECT DAY")
                    Toast.makeText(this,"select day",Toast.LENGTH_LONG).show();
                else
                { SQLiteDatabase db = db1.getWritableDatabase();
                    boolean result=db1.insertData(db,cz,s,c);
                if(result)
                Toast.makeText(this,"added"+c,Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(this,"not added"+c,Toast.LENGTH_LONG).show();
            }
        }
        Toast.makeText(MainActivity.this,check1+" "+check2+" "+check3,LENGTH_LONG).show();
        }
        catch(Exception e)
        {
            Toast.makeText(this,"error"+e,Toast.LENGTH_LONG).show();
        }
    }
    private int  validate(String registerdate) {

        String regEx = "^(0[1-9]|1[012])[- /.](0[1-9]|[12][0-9]|3[01])[- /.](19|20)\\d{2}$";
        Matcher matcherObj = Pattern.compile(regEx).matcher(registerdate);
        if (matcherObj.matches())
        {
            return 1;
        }
        else
        {
            return -1;
        }
    }

    public void viewdata(View view) {
        // btnviewAll.setOnClickListener(
        //       new View.OnClickListener() {
        //         @Override
        //       public void onClick(View v) {

        try{ SQLiteDatabase db = db1.getReadableDatabase();
            Cursor res = db1.getAllData(db);
            if(res.getCount() == 0) {
                // show message
                showMessage("Error","Nothing found");
                return;
            }

            StringBuffer buffer = new StringBuffer();
            while (res.moveToNext()) {
                buffer.append("Id :"+ res.getString(0)+"\n");
                buffer.append("day :"+ res.getString(1)+"\n");
                buffer.append("subject :"+ res.getString(2)+"\n");
                //buffer.append("what happened :"+ res.getString(3)+"\n");
            }

            // Show all data
            showMessage("Data",buffer.toString());
            res.close();
        }
        catch(Exception e)
        {
            Toast.makeText(this,"error in view"+e,LENGTH_LONG).show();
        }
    }

    public void viewsub(View view) {
        // btnviewAll.setOnClickListener(
        //       new View.OnClickListener() {
        //         @Override
        //       public void onClick(View v) {
        SQLiteDatabase db = db1.getReadableDatabase();
        try{ Cursor res = db1.getAllData2(db);
            if(res.getCount() == 0) {
                // show message
                showMessage("Error","Nothing found");
                return;
            }

            StringBuffer buffer = new StringBuffer();
            while (res.moveToNext()) {
                buffer.append("day :"+ res.getString(0)+"\n");
                buffer.append("number of subject :"+ res.getString(1)+"\n");
                // buffer.append("day :"+ res.getString(2)+"\n");
                //buffer.append("number of subjects :"+ res.getString(3)+"\n");
            }

            // Show all data
            showMessage("Data",buffer.toString());
            res.close();
        }
        catch(Exception e)
        {
            Toast.makeText(this,"error in view"+e,LENGTH_LONG).show();
        }
    }
    public void viewd1(View view) {
        // btnviewAll.setOnClickListener(
        //       new View.OnClickListener() {
        //         @Override
        //       public void onClick(View v) {
        try{ SQLiteDatabase db = db1.getReadableDatabase();
            Cursor res = db1.getAllData1(db);
            if(res.getCount() == 0) {
                // show message
                showMessage("Error","Nothing found");
                return;
            }

            StringBuffer buffer = new StringBuffer();
            while (res.moveToNext()) {
                buffer.append("starting date :"+ res.getString(0)+"\n");
                buffer.append("end date :"+ res.getString(1)+"\n");
               // buffer.append("day :"+ res.getString(2)+"\n");
                //buffer.append("number of subjects :"+ res.getString(3)+"\n");
            }

            // Show all data
            showMessage("Data",buffer.toString());
            res.close();
        }
        catch(Exception e)
        {
            Toast.makeText(this,"error in view"+e,LENGTH_LONG).show();
        }

    }
    // );
    //}
    public void showMessage(String title,String Message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();
    }
    public void next1(View view)
    {
        Intent newact=new Intent(this,a1.class);
        startActivity(newact);
    }
    public void next2(View view)
    {
        Intent newact=new Intent(this,Main2Activity.class);
        startActivity(newact);
    }
}
