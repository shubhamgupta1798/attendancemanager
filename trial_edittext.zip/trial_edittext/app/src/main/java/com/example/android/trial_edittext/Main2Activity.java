package com.example.android.trial_edittext;

import android.app.DatePickerDialog;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.icu.text.SimpleDateFormat;
import android.icu.util.Calendar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Date;
import java.util.Locale;

import static android.widget.Toast.LENGTH_LONG;
import static android.widget.Toast.LENGTH_SHORT;
import static android.widget.Toast.makeText;

public class Main2Activity extends AppCompatActivity {
    StarbuzzDatabaseHelper db1=new StarbuzzDatabaseHelper(this);
    EditText editText;
    Calendar myCalendar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Calendar c = Calendar.getInstance();


        Toast.makeText(Main2Activity.this,"hello",Toast.LENGTH_LONG).show();



        int weekDay=c.get(Calendar.DAY_OF_WEEK);
        String s;
        if(weekDay==1)
            s="SUNDAY";
        else if(weekDay==2)
            s="MONDAY";
        else if(weekDay==3)
            s="TUESDAY";
        else if(weekDay==4)
            s="WEDNESDAY";



        else if(weekDay==5)
            s="THURSDAY";

        else if(weekDay==6)
            s="FRIDAY";
        else
            s="SATURDAY";
        try{
            fn1(s);}
        catch (Exception e)
        {
            Toast.makeText(this,""+e,Toast.LENGTH_LONG).show();
        }

        try {
            Toast.makeText(Main2Activity.this,s,LENGTH_LONG).show();
            //setdate(s);

        }
        catch (Exception e)
        {
            Toast.makeText(Main2Activity.this,""+e,LENGTH_LONG).show();
        }


        try {
            myCalendar = Calendar.getInstance();
            // private int dayOfMonth,monthOfYear,year;



            editText= (EditText) findViewById(R.id.Birthday);

            updateLabel();


            final DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {

                @Override
                public void onDateSet(DatePicker view, int year, int monthOfYear,
                                      int dayOfMonth) {
                    // TODO Auto-generated method stub
                    myCalendar.set(Calendar.YEAR, year);
                    myCalendar.set(Calendar.MONTH, monthOfYear);
                    myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                    SimpleDateFormat simpledateformat = new SimpleDateFormat("EEEE");
                    Date date = new Date(year,monthOfYear, dayOfMonth-1);
                    String dayOfWeek = simpledateformat.format(date);
                    String weekDay = dayOfWeek;
                    try {
                        if(weekDay.equals("Monday"))
                            weekDay="MONDAY";
                        else if(weekDay.equals("Tuesday"))
                            weekDay="TUESDAY";
                        else if(weekDay.equals("Wednesday"))
                            weekDay="WEDNESDAY";
                        else if(weekDay.equals("Thursday"))
                            weekDay="THURSDAY";
                        else
                            weekDay="FRIDAY";



                        Toast.makeText(Main2Activity.this,weekDay,LENGTH_LONG).show();
                        fn1(weekDay);
                    }
                    catch (Exception e)
                    {
                        Toast.makeText(Main2Activity.this,""+e,LENGTH_LONG).show();

                    }

                    editText= (EditText) findViewById(R.id.Birthday);
                    updateLabel();

                }

            };


            editText.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {

                    new DatePickerDialog(Main2Activity.this, date, myCalendar
                            .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                            myCalendar.get(Calendar.DAY_OF_MONTH)).show();

                }
            });

        } catch (Exception e) {
            Toast tb = makeText(this, "issue in oncreate function ", LENGTH_SHORT);
            tb.show();
        }
    }

    private void fn1(String day) {
        SQLiteDatabase db = db1.getReadableDatabase();
       int finalv= db1.find11(db,day);
        if(finalv==-1)
            Toast.makeText(this,"error1",Toast.LENGTH_LONG).show();
        f2(finalv,day);
        ((ViewGroup) findViewById(R.id.radiogroup)).removeAllViews();
        for(int i=1;i<=finalv;i++)
            addRadioButtons(i);

    }
    public void f2(int finalv,String day){
    LinearLayout linearLayout= (LinearLayout)findViewById(R.id.linear);      //find the linear layout
    linearLayout.removeAllViews();                              //add this too
    for(int i=0; i<finalv;i++){          //looping to create 5 textviews

        TextView textView= new TextView(this);              //dynamically create textview
        textView.setLayoutParams(new LinearLayout.LayoutParams(             //select linearlayoutparam- set the width & height
                ViewGroup.LayoutParams.MATCH_PARENT,250));

        //textView.setGravity(Gravity.CENTER_VERTICAL);
        int c=i+1;
        String j=""+c;//set the gravity too
        textView.setText(""+setdate(day,j));                                    //adding text
        linearLayout.addView(textView);                                     //inflating :)
    }
    }


    public void addRadioButtons(int id) {


            RadioGroup ll = new RadioGroup(this);
            ll.setOrientation(LinearLayout.VERTICAL);

            ll.setId((id));
            for (int i = 1; i <= 3; i++) {
                RadioButton rdbtn = new RadioButton(this);
                rdbtn.setId(i+id*10);
                if(i==1)
                    rdbtn.setText("yes " );
                else if (i==2)
                    rdbtn.setText("no " );
                else
                    rdbtn.setText("attendance not taken " );
                ll.addView(rdbtn);
            }
            ((ViewGroup) findViewById(R.id.radiogroup)).addView(ll);


    }
    private void updateLabel() {
        try {
            //Toast.makeText(a1.this,"hello1",Toast.LENGTH_LONG).show();

            String myFormat = "dd/MM/yy"; //In which you need put here
            SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

            editText.setText(sdf.format(myCalendar.getTime()));

        } catch (Exception e) {
            Toast tb = makeText(this, "issue is in update label function and the issue is\n\n"+e, LENGTH_LONG);
            tb.show();
        }
    }

    public String setdate(String day,String id) {




            SQLiteDatabase db = db1.getReadableDatabase();
            String c = db1.findsubject(db,id,day);

            return c;



    }
}
